/**
 * news.js — Express router for all news endpoints.
 *
 * GET /api/news               — latest news with optional filters
 * GET /api/news/search        — full-text search
 * GET /api/news/category/:type — category-filtered feed
 */

import { Router } from 'express';
import {
  getLatestNews,
  searchNews,
  getNewsByCategory,
} from '../services/newsDataService.js';

const router = Router();

/**
 * Shared query param extractor.
 * NewsData.io uses ISO 3166-1 alpha-2 country codes (e.g. "in", "us")
 * and BCP 47 language codes (e.g. "en", "hi").
 */
function extractCommonParams(query) {
  const { country, language, page } = query;
  return {
    country: country?.trim().toLowerCase() || undefined,
    language: language?.trim().toLowerCase() || undefined,
    page: page?.trim() || undefined,
  };
}

/**
 * GET /api/news
 * Query params: q, country, language, category, page
 */
router.get('/', async (req, res, next) => {
  try {
    const { q, category } = req.query;
    const common = extractCommonParams(req.query);
    const data = await getLatestNews({
      q: q?.trim() || undefined,
      category: category?.trim().toLowerCase() || undefined,
      ...common,
    });
    res.json({ success: true, ...data });
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/news/search?q=...&country=...&language=...&page=...
 */
router.get('/search', async (req, res, next) => {
  try {
    const { q } = req.query;
    if (!q?.trim()) {
      return res.status(400).json({ success: false, error: 'Query parameter "q" is required' });
    }
    const common = extractCommonParams(req.query);
    const data = await searchNews(q.trim(), common);
    res.json({ success: true, ...data });
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/news/category/:type
 * :type must be one of the NewsData.io category slugs
 * Query params: country, language, page
 */
router.get('/category/:type', async (req, res, next) => {
  try {
    const { type } = req.params;
    const common = extractCommonParams(req.query);
    const data = await getNewsByCategory(type, common);
    res.json({ success: true, ...data });
  } catch (err) {
    next(err);
  }
});

export default router;
