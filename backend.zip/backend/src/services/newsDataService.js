/**
 * newsDataService.js
 * Single-responsibility service for all NewsData.io API communication.
 * Never called directly from routes — use this as the data layer.
 */

import NodeCache from 'node-cache';

const BASE_URL = 'https://newsdata.io/api/1/latest';

// In-memory cache: avoids hammering the free-tier rate limit (200 req/day)
const cache = new NodeCache({
  stdTTL: parseInt(process.env.CACHE_TTL ?? '300', 10), // 5 min default
  checkperiod: 60,
  useClones: false,
});

/**
 * Build a deterministic cache key from query params.
 * @param {Record<string, string|number|boolean>} params
 */
function buildCacheKey(params) {
  return Object.entries(params)
    .filter(([, v]) => v !== undefined && v !== null && v !== '')
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([k, v]) => `${k}:${v}`)
    .join('|');
}

/**
 * Core fetch wrapper — adds API key, caching, and structured error handling.
 * @param {Record<string, string|number|boolean>} params
 */
async function fetchFromNewsData(params) {
  const apiKey = process.env.NEWSDATA_API_KEY;
  if (!apiKey) {
    throw new Error('NEWSDATA_API_KEY is not configured');
  }

  // Strip empty/undefined values before caching and fetching
  const cleanParams = Object.fromEntries(
    Object.entries(params).filter(([, v]) => v !== undefined && v !== null && v !== '')
  );

  const cacheKey = buildCacheKey(cleanParams);
  const cached = cache.get(cacheKey);
  if (cached) {
    return { ...cached, _cached: true };
  }

  const url = new URL(BASE_URL);
  url.searchParams.set('apikey', apiKey);
  url.searchParams.set('removeduplicate', '1'); // Always deduplicate
  for (const [key, value] of Object.entries(cleanParams)) {
    url.searchParams.set(key, String(value));
  }

  const response = await fetch(url.toString());

  if (!response.ok) {
    const body = await response.text().catch(() => '');
    throw new NewsDataError(
      `NewsData API responded with ${response.status}`,
      response.status,
      body
    );
  }

  const data = await response.json();

  if (data.status !== 'success') {
    throw new NewsDataError(
      data.results?.message ?? 'NewsData API returned a non-success status',
      422,
      data
    );
  }

  const result = {
    articles: transformArticles(data.results ?? []),
    nextPage: data.nextPage ?? null,
    totalResults: data.totalResults ?? 0,
    _cached: false,
  };

  cache.set(cacheKey, result);
  return result;
}

/**
 * Map raw NewsData.io article objects to the shape expected by the
 * NewsQuest frontend (Article interface in gameStore.ts).
 * @param {Array<Record<string, unknown>>} rawArticles
 */
function transformArticles(rawArticles) {
  return rawArticles
    .filter((a) => a.title && a.description) // Drop stub entries
    .map((a) => ({
      id: a.article_id ?? slugify(a.title),
      headline: a.title,
      summary: a.description ?? '',
      fullContent: a.content ?? a.description ?? '',
      category: normaliseCategory(a.category),
      source: a.source_id ?? a.source_name ?? 'Unknown',
      publishedAt: a.pubDate ?? new Date().toISOString(),
      readTime: estimateReadTime(a.content ?? a.description ?? ''),
      imageUrl: a.image_url ?? null,
      sourceUrl: a.link ?? null,
      // Gamification fields — computed heuristically for real articles
      difficulty: inferDifficulty(a),
      xpReward: inferXP(a),
      // quiz and prediction intentionally omitted — generated separately
      quiz: [],
      prediction: null,
    }));
}

/** Map NewsData categories to NewsQuest's internal category set. */
function normaliseCategory(rawCategory) {
  if (!rawCategory) return 'General';
  const first = Array.isArray(rawCategory) ? rawCategory[0] : rawCategory;
  const map = {
    technology: 'Technology',
    science: 'Science',
    business: 'Economy',
    entertainment: 'Culture',
    sports: 'Sports',
    health: 'Science',
    politics: 'Polity',
    environment: 'Environment',
    world: 'World',
    top: 'General',
  };
  return map[first?.toLowerCase()] ?? 'General';
}

function slugify(title) {
  return title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '')
    .slice(0, 60);
}

function estimateReadTime(text) {
  const words = text.trim().split(/\s+/).length;
  const minutes = Math.max(1, Math.round(words / 200));
  return `${minutes} min`;
}

/** Infer quiz difficulty from article metadata. */
function inferDifficulty(article) {
  const wordCount = (article.content ?? '').split(/\s+/).length;
  if (wordCount > 500) return 'Hard';
  if (wordCount > 200) return 'Medium';
  return 'Easy';
}

function inferXP(article) {
  const map = { Hard: 25, Medium: 20, Easy: 15 };
  return map[inferDifficulty(article)] ?? 15;
}

/** Structured error class for NewsData API failures. */
export class NewsDataError extends Error {
  constructor(message, statusCode = 500, raw = null) {
    super(message);
    this.name = 'NewsDataError';
    this.statusCode = statusCode;
    this.raw = raw;
  }
}

// ─── Public service methods ───────────────────────────────────────────────────

/**
 * Fetch latest news with optional filters.
 * @param {{ q?: string, country?: string, language?: string, category?: string, page?: string }} options
 */
export async function getLatestNews({ q, country, language, category, page } = {}) {
  return fetchFromNewsData({ q, country, language, category, page });
}

/**
 * Full-text search across news articles.
 * @param {string} query
 * @param {{ country?: string, language?: string, page?: string }} options
 */
export async function searchNews(query, { country, language, page } = {}) {
  if (!query?.trim()) throw new NewsDataError('Search query cannot be empty', 400);
  return fetchFromNewsData({ q: query.trim(), country, language, page });
}

/**
 * Fetch news by category.
 * Supported: business | entertainment | environment | food | health |
 *            politics | science | sports | technology | top | world
 * @param {string} category
 * @param {{ country?: string, language?: string, page?: string }} options
 */
export async function getNewsByCategory(category, { country, language, page } = {}) {
  const valid = ['business', 'entertainment', 'environment', 'food', 'health',
    'politics', 'science', 'sports', 'technology', 'top', 'world'];
  if (!valid.includes(category.toLowerCase())) {
    throw new NewsDataError(`Invalid category '${category}'. Valid: ${valid.join(', ')}`, 400);
  }
  return fetchFromNewsData({ category: category.toLowerCase(), country, language, page });
}

/** Expose cache stats for health/debug endpoint. */
export function getCacheStats() {
  return cache.getStats();
}

/** Manually bust the cache (useful after config changes). */
export function flushCache() {
  cache.flushAll();
}
