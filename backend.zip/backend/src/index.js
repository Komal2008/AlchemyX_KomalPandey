/**
 * index.js — NewsQuest backend entry point.
 * Starts an Express server that proxies NewsData.io requests.
 */

import dotenv from "dotenv";
dotenv.config({ path: "./.env" });

console.log("API KEY:", process.env.NEWSDATA_API_KEY); // debug
import express from 'express';
import cors from 'cors';
import rateLimit from 'express-rate-limit';

import newsRouter from './routes/news.js';
import { errorHandler } from './middleware/errorHandler.js';
import { getCacheStats, flushCache } from './services/newsDataService.js';

const app = express();
const PORT = process.env.PORT ?? 3001;

// ─── Security / CORS ──────────────────────────────────────────────────────────
app.use(cors({
  origin: process.env.CORS_ORIGIN ?? 'http://localhost:4000',
  methods: ['GET'],
  allowedHeaders: ['Content-Type'],
}));

// ─── Rate limiting (protects your NewsData quota) ─────────────────────────────
const limiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 60,             // 60 req/min per IP — well under NewsData free tier
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'Too many requests, please try again shortly.' },
});
app.use('/api', limiter);

// ─── Body parsing ─────────────────────────────────────────────────────────────
app.use(express.json());

// ─── Routes ───────────────────────────────────────────────────────────────────
app.use('/api/news', newsRouter);

// Health check — useful for uptime monitoring
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    uptime: Math.floor(process.uptime()),
    cache: getCacheStats(),
    timestamp: new Date().toISOString(),
  });
});

// Cache flush (restrict to localhost in production)
app.post('/api/cache/flush', (req, res) => {
  if (process.env.NODE_ENV === 'production' && req.ip !== '127.0.0.1') {
    return res.status(403).json({ success: false, error: 'Forbidden' });
  }
  flushCache();
  res.json({ success: true, message: 'Cache cleared' });
});

// 404 catch-all for /api
app.use('/api', (_req, res) => {
  res.status(404).json({ success: false, error: 'Endpoint not found' });
});

// ─── Global error handler (must be last) ─────────────────────────────────────
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`\n🚀  NewsQuest backend running on http://localhost:${PORT}`);
  console.log(`📰  GET /api/news`);
  console.log(`🔍  GET /api/news/search?q=...`);
  console.log(`🗂️   GET /api/news/category/:type`);
  console.log(`❤️   GET /api/health\n`);
});
