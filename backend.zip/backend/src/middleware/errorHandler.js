/**
 * errorHandler.js
 * Centralised error middleware — converts thrown errors into clean JSON responses.
 */

import { NewsDataError } from '../services/newsDataService.js';

/**
 * Express error-handling middleware (4-arg signature required by Express).
 */
export function errorHandler(err, req, res, _next) {
  // Known API errors — pass through their status code
  if (err instanceof NewsDataError) {
    return res.status(err.statusCode).json({
      success: false,
      error: err.message,
      ...(process.env.NODE_ENV === 'development' && { raw: err.raw }),
    });
  }

  // Validation errors (thrown as plain Error with a statusCode property)
  if (err.statusCode) {
    return res.status(err.statusCode).json({ success: false, error: err.message });
  }

  // Unexpected errors
  console.error('[Unhandled error]', err);
  return res.status(500).json({
    success: false,
    error: 'Internal server error',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
  });
}
